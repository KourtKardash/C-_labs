﻿// dllmain.cpp : Определяет точку входа для приложения DLL.
#include "pch.h"
#include "framework.h"
#include "mkl.h"
#include "mkl_df_defines.h"
#include <iostream>
#include <vector>
#include "mkl_df_types.h"
#include "mkl_blacs.h"

extern "C" _declspec(dllexport)
int CubicSpline(
    int nX,
    const double* X,
    int nY,
    const double* Y,
    double d1L,
    double d1R,
    const int nS,
    double sL,
    double sR,
    double* splineValues
)
{
    double* scoeff = new double[nY * (nX - 1) * DF_PP_CUBIC];
    try {
        DFTaskPtr task;
        int status = -1;

        status = dfdNewTask1D(&task,
            nX, X,
            DF_NON_UNIFORM_PARTITION,
            nY, Y,
            DF_NO_HINT);
        if (status != DF_STATUS_OK) throw 1;
        double bc[2]{ d1L, d1R };
        status = dfdEditPPSpline1D(
            task,
            DF_PP_CUBIC, DF_PP_NATURAL, DF_BC_1ST_LEFT_DER | DF_BC_1ST_RIGHT_DER, bc,
            DF_NO_IC,
            NULL,
            scoeff,
            DF_NO_HINT);
        if (status != DF_STATUS_OK) throw 2;

        status = dfdConstruct1D(task,
            DF_PP_SPLINE,
            DF_METHOD_STD);
        if (status != DF_STATUS_OK) throw 3;
        double grid[2]{ sL, sR };
        int nDorder = 2;
        MKL_INT dorder[] = { 1,1 }; //probably there must be one more 1

        status = dfdInterpolate1D(task,
            DF_INTERP,
            DF_METHOD_PP,
            nS, grid,
            DF_UNIFORM_PARTITION,
            nDorder, dorder,
            NULL,
            splineValues,
            DF_NO_HINT,
            NULL);
        if (status != DF_STATUS_OK) throw 4;

        status = dfDeleteTask(&task);
        if (status != DF_STATUS_OK) throw 6;
    }
    catch (int ret) {
        delete[] scoeff;
        return ret;
    }
    delete[] scoeff;
    return 0;
}

/*extern "C" _declspec (dllexport)
void test() {
    std::cout << "hello";
}*/

