﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Prac
{
    public class V2MainCollection : System.Collections.ObjectModel.ObservableCollection<V2Data>
    {
        public int Count_zero
        {
            get
            {
                if (this.Count == 0)
                {
                    return -1;
                }
                int len = (from item in this
                           from dt in item
                           where (dt.field[0] == 0.0 && dt.field[1] == 0.0)
                           select dt).Count();
                return len;
            }
        }
        public DataItem? Max_mod
        {
            get
            {
                if (this.Count == 0) 
                { 
                    return null; 
                }
                IEnumerable<DataItem> temp = from item in this
                                             from dt in item
                                             select dt;
                IEnumerable<DataItem> temp2 = from item in temp
                                              orderby Math.Sqrt(item.field[0] * item.field[0] + item.field[1] * item.field[1]) descending
                                              select item;
                return temp2.First();

            } //Math.Sqrt(dt.field[0] * dt.field[0] + dt.field[1] * dt.field[1]))
        }
        public IEnumerable<double> Unique_x
        {
            get
            {
                if (this.Count == 0)
                {
                    return null;
                }
                IEnumerable<DataItem> temp = from item in this
                                             from dt in item
                                             select dt;
                IEnumerable<double> temp1 = from dt1 in temp
                                            select dt1.x;
                IEnumerable<double> y = temp1.GroupBy(dt => dt).Where(dt => dt.Count() == 1).Select(dt => dt.First());

                IEnumerable<double> x = from dt in y
                                        orderby dt
                                        select dt;
                return x;
            }
        } 
        public bool Contains(string key)
        {
            return Items.Any(elem => elem.key == key);
        }
        public new bool Add(V2Data v2Data)
        {
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].key == v2Data.key) return false;
            }
            Items.Add(v2Data);
            return true;
        }
        public V2MainCollection(int nV2DataArray, int nV2DataList)
        {
            double[] x = new double[3];
            for (int i = 1; i < nV2DataArray; ++i)
            {
                x[0] = i -1;
                x[1] = i*i + 2.4;
                x[2] = i*i + 3.1;
                V2DataArray arr = new V2DataArray("arr" + i, DateTime.Today, x, Program.F1);
                Add(arr);
            }
            V2DataArray arr1 = new V2DataArray("arr" + nV2DataArray, DateTime.Now);
            Add(arr1);
            for (int i = 1; i < nV2DataList; ++i)
            {
                x[0] = i - 1;
                x[1] = i * i - 2.4;
                x[2] = i * i - 3.1;
                V2DataList list = new V2DataList("list" + i, DateTime.Today, x, Program.F2);
                Add(list);
            }
            V2DataList list1 = new V2DataList("list" + nV2DataList, DateTime.Now);
            Add(list1);
        }
        public string ToLongString(string format)
        {
            var res = new StringBuilder();
            for (int i = 0; i < Items.Count; ++i)
            {
                res.AppendLine($"{Items[i].ToLongString(format)}\n");
            }
            return $"{res}";
        }
        public override string ToString()
        {
            var res = new StringBuilder();
            for (int i = 0; i < Items.Count; ++i)
            {
                res.AppendLine($"{Items[i].ToString()}\n");
            }
            return res.ToString();
        }
        public List<bool> bools //НОВЫЙ
        {
            get
            {
                List<bool> ans = new List<bool> { };
                for (int i = 0; i < Items.Count; ++i)
                {
                    if (Items[i].IsNull == true) ans.Add(true);
                    else ans.Add(false);
                }
                return ans;
            }
        }
    }
}
