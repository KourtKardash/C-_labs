﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Prac
{
    public delegate void FValues(double x, ref double y1, ref double y2);
    public class V2DataArray: V2Data
    {
        
        public double[] X { get; set; }
        public double[,] Field { get; set; }
        public V2DataArray(string key, DateTime date): base(key, date)
        {
            X = new double[0];
            Field = new double[2,0];
        }
        public V2DataArray(string key, DateTime date, double[] x, FValues F): base(key, date)
        {
            X = (double[])x.Clone();
            Field = new double[2, X.Length];
            for(int i = 0; i < X.Length; i++)
            {
                F(X[i], ref Field[0, i], ref Field[1, i]);
            }
        }
        public V2DataArray(string key, DateTime date, int nX, double xL, double xR, FValues F): base (key, date)
        {
            double step = (xR - xL) / (nX - 1);
            X = new double[nX];
            Field = new double[2, nX];
            for (int i = 0; i < nX; i++)
            {
                X[i] = xL + i * step;
                F(X[i], ref Field[0, i], ref Field[1, i]);
            }
        }
        public override IEnumerator<DataItem> GetEnumerator()
        {
            for (int i = 0; i < X.Length; ++i)
            {
                DataItem dt = new DataItem(X[i], Field[0,i], Field[1,i]);
                yield return dt;
            }
        }
        public bool Save(string filename)
        {
            string str = this.ToLongString("F3");
            StreamWriter fs = null;
            try
            {
                fs = new StreamWriter(filename);
                fs.WriteLine(str);
                fs.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                }
            }
            return true;
        }
        static public bool Load(string filename, ref V2DataArray V2)
        {
            StreamReader fs0 = null;
            try
            {
                fs0 = new StreamReader(filename);
                string s = fs0.ReadLine();
                s = fs0.ReadLine();
                int i = 0, j = 0;
                while (i < s.Length) {
                    if (s[i] == ' ') ++j;
                    if (j == 2) break;
                    ++i;
                }
                ++i;
                V2.key = s.Substring(i);
                s = fs0.ReadLine();
                i = 7;
                j = 7;
                while (s[j] != '.') ++j;
                int i1 = Int32.Parse(s.Substring(i, j - i));
                ++j;
                i = j;
                while (s[j] != '.') ++j;
                int i2 = Int32.Parse(s.Substring(i, j - i));
                ++j;
                i = j;
                while (s[j] != ' ') ++j;
                int i3 = Int32.Parse(s.Substring(i, j - i));
                ++j;
                i = j;
                while (s[j] != ':') ++j;
                int i4 = Int32.Parse(s.Substring(i, j - i));
                ++j;
                i = j;
                while (s[j] != ':') ++j;
                int i5 = Int32.Parse(s.Substring(i, j - i));
                ++j;
                int i6 = Int32.Parse(s.Substring(j));
                V2.Date = new DateTime(i3, i2, i1, i4, i5, i6);

                s = fs0.ReadLine();
                List <DataItem> list = new List<DataItem> ();
                while(s != null && s != "")
                {   
                    i = j = 4;
                    while (s[j] != ';') ++j;
                    double x = Double.Parse(s.Substring(i, j - i));
                    j += 7;
                    i = j;
                    while (s[j] != ';') ++j;
                    double y1 = Double.Parse(s.Substring(i, j - i));
                    j += 7;
                    i = j;
                    double y2 = Double.Parse(s.Substring(i));
                    list.Add(new DataItem (x, y1, y2));
                    s = fs0.ReadLine();
                }
                int n = list.Count;
                V2.X = new double[n];
                V2.Field = new double[2, n];
                for (int k = 0; k < n; ++k)
                {
                    V2.X[k] = list[k].x;
                    V2.Field[0, k] = list[k].field[0];
                    V2.Field[1, k] = list[k].field[1];
                }
                fs0.Close();
            }
            finally
            {
                if (fs0 != null) 
                    fs0.Close();
            }
            return true;
        }
        public double[] this[int index]
        {
            get
            {
                if (index != 0 && index != 1) throw new ArgumentOutOfRangeException("Index is incorrect");
                double[] ret = new double[X.Length];
                for (int i = 0; i < ret.Length; ++i)
                {
                    ret[i] = Field[index, i];
                }
                return ret;
            }
        }
        public static explicit operator V2DataList(V2DataArray source)
        {
            V2DataList ret_list = new V2DataList(source.key, source.Date);
            for (int i = 0; i < source.X.Length; ++i)
            {
                DataItem cur = new DataItem(source.X[i], source.Field[0, i], source.Field[1, i]);
                ret_list.DataList.Add(cur);
            }
            return ret_list;
        }
        public override double MinField
        {
            get
            {
                double y1 = Math.Abs(Field[0, 0]);
                double y2 = Math.Abs(Field[1, 0]);
                double min = Math.Min(y1, y2);
                for(int i = 0; i < X.Length; ++i)
                {
                    y1 = Math.Abs(Field[0, i]);
                    y2 = Math.Abs(Field[1, i]);
                    min = Math.Min(min, y1);
                    min = Math.Min(min, y2);
                }
                return min;
            }
        }
        public override bool IsNull //НОВЫЙ
        {
            get
            {
                for(int i = 0; i < X.Length; ++i)
                {
                    if (Field[0, i] == 0 && Field[1, i] == 0)
                    {
                        return true;
                    }
                }
                return false;
            }
        }
        public override string ToString()
        {
            return $"V2DataArray\n{base.ToString()}";
        }
        public override string ToLongString(string format)
        {
            var res = new StringBuilder();
            res.AppendLine(ToString());
            for(int i = 0; i < X.Length; ++i)
            {
                res.AppendLine($"x = {X[i].ToString(format)}; y1 = {Field[0, i].ToString(format)}; y2 = {Field[1, i].ToString(format)}");
            }
            return res.ToString();
        }
    }
}
