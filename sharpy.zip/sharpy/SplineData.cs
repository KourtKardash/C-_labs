﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Prac
{
    public class SplineData
    {
        public V2DataArray DataArray { get; set; }
        public double d1L {  get; set; }
        public double d1R {  get; set; }
        public int nS { get; set; } //число узлов
        public double[] SplineValues { get; set; }
        public List<SplineDataItem> SplineElems { get; set; }

        public SplineData(V2DataArray dataArray, double d1l, double d1r , int m)
        {
            DataArray = dataArray;
            nS = m;
            d1L = d1l;
            d1R = d1r;
            SplineElems = new List<SplineDataItem>();
        }
        public string ToLongString(string format)
        {
            var res = new StringBuilder();
            for (int i = 0; i < nS; ++i)
            {
                res.AppendLine($"{SplineElems[i].ToString(format)}");
            }
            return res.ToString();
        }

        // Метод для сохранения в файл
        public bool Save(string filename, string format)
        {
            try
            {
                using (StreamWriter fs = new StreamWriter(filename))
                {
                    fs.WriteLine(ToLongString(format));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            return true;
        }
        public void method()
        {
            double xL = DataArray.X[0]; // левый конец отрезка
            double xR = DataArray.X[DataArray.X.Length-1]; // правый конец отрезка
            //double xL = 0; // левый конец отрезка
            //double xR = 1.0; // правый конец отрезка
            int nX = DataArray.X.Length; // число узлов сплайна
            double[] X = new double[nX]; // массив узлов сплайна
                                         // Равномерная сетка на отрезке [xL, xR]
            for(int i = 0; i < nX; i++) X[i] = DataArray.X[i];

            int nY = 1; // размерность векторной функции
            double[] Y = new double[nX]; // массив заданных значений векторной функции
            for (int j = 0; j < nX; j++) Y[j] = DataArray.Field[0, j];

            //d1L = 0; // значение первой производной сплайна на левом конце
            //d1R = 3; // значение первой производной сплайна на правом конце
                            // Равномерная сетка, на которой вычисляются значения сплайна и производных
            //nS = 9; // число узлов равномерной сетки
            double sL = xL; // левый конец отрезка
            double sR = xR; // правый конец отрезка
                            // Массив узлов на отрезке [sL, sR]
            double[] sites = new double[nS];
            double hS = (sR - sL) / (nS - 1); // шаг сетки
            sites[0] = sL;
            for (int j = 0; j < nS; j++) sites[j] = sites[0] + hS * j;
            SplineValues = new double[2 * nS]; // массив вычисленных значений
                                               // сплайна и его производных
            
            try
            {
                int ret = CubicSpline(
                nX,
                X,
                nY,
                Y,
                d1L,
                d1R,
                nS,
                sL,
                sR,
                SplineValues
                );

                Console.WriteLine($"ret = {ret}\n");
                Console.WriteLine($"Заданные значения в узлах сплайна");
                for (int j = 0; j < nX; j++)
                    Console.WriteLine($"X[{j}] = {X[j].ToString("F3")}" +
                    $" Y[{j}] = {Y[j].ToString("F6")}");
                Console.WriteLine($"\nВычисленные значения сплайна и производных");
                Console.WriteLine($"\nУзел Значение Первая");
                Console.WriteLine($"сетки сплайна производная");
                for (int j = 0; j < nS; j++)
                {
                    Console.WriteLine($"{sites[j].ToString("F3")}" +
                    $" {SplineValues[2 * j].ToString("F6")}" +
                    $" {SplineValues[2 * j + 1].ToString("F6")} ");
                    SplineDataItem p = new SplineDataItem(sites[j], SplineValues[2 * j], SplineValues[2 * j + 1]);
                    SplineElems.Add(p);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка сплайн-интерполяции\n{ex}");
            }
        }

        [DllImport("C:\\Users\\Svetlana\\Desktop\\папка_с_проектами\\New_solution\\Build\\x64\\Debug\\dll.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int CubicSpline(int nX,
            double[] X,
            int nY,
            double[] Y,
            double d1L, double d1R,
            int nS, double sL, double sR, double[] splineValues
        );
        /*[DllImport("C:\\Users\\Svetlana\\Desktop\\Prac\\Build\\x64\\Debug\\Dll2.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void test();*/
    }
}
