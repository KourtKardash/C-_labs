﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac
{
    public struct SplineDataItem
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Y_p { get; set; }
        public SplineDataItem(double x, double y, double y_p)
        {
            X = x;
            Y = y;
            Y_p = y_p;
        }
        // Перегруженный метод ToString
        public override string ToString()
        {
            return $"X: {X}, Y: {Y}, Y_p: {Y_p}";
        }

        // Метод ToString с форматированием
        public string ToString(string format)
        {
            return $"X: {X.ToString(format)}, Y: {Y.ToString(format)}, Y_p: {Y_p.ToString(format)}";
        }
    }
}
