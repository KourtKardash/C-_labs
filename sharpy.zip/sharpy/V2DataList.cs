﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace Prac
{
    public class V2DataList: V2Data 
    {
        public delegate DataItem FDI(double x);
        public List<DataItem> DataList { get; set; } //динамический массив
        public V2DataList(string key, DateTime date): base (key, date) //вызывает конструктор баз. класса
        {
            DataList = new List<DataItem> ();
        }
        public V2DataList(string key, DateTime date, double[] x, FDI F): this(key, date)
        {
            for(int i = 0; i < x.Length; ++i)
            {
                //double[] tmp = F(x[i]);
                bool exists = DataList.Exists(y => y.x == x[i]);
                if(!exists)
                {
                    DataList.Add(F(x[i]));
                }
            }
        }
        public override IEnumerator<DataItem> GetEnumerator()
        {
            return DataList.GetEnumerator();
        }
        public override double MinField //свойство
        {
            get 
            {
                double y1, y2;
                y1 = Math.Abs(DataList[0].field[0]);
                y2 = Math.Abs(DataList[0].field[1]);
                double min = Math.Min(y1, y2);
                for(int i = 1; i < DataList.Count; ++i)
                {
                    y1 = Math.Abs(DataList[i].field[0]);
                    y2 = Math.Abs(DataList[i].field[1]);
                    min = Math.Min(min, y1);
                    min = Math.Min(min, y2);
                }
                return min;
            }
        }
        public override bool IsNull //НОВЫЙ
        {
            get
            {
                for(int i = 0; i < DataList.Count; ++i)
                {
                    if (DataList[i].field[0] == 0 && DataList[i].field[1] == 0)
                    {
                        return true;
                    }
                }
                return false;
            }
        }
        public V2DataArray Prop
        {
            get
            {
                V2DataArray ret = new V2DataArray(key, Date);
                ret.X = new double[DataList.Count];
                ret.Field = new double[2, DataList.Count];
                for (int i = 0; i < DataList.Count; ++i)
                {
                    var cur = DataList[i];
                    ret.X[i] = cur.x;
                    ret.Field[0, i] = cur.field[0];
                    ret.Field[1, i] = cur.field[1];
                }
                return ret;
            }
        }
        public override string ToString()
        {
            return $"V2DataList\n{base.ToString()}, count = {DataList.Count}";
        }
        public override string ToLongString(string format)
        {
            var res = new StringBuilder();
            res.AppendLine(ToString());
            for(int i = 0; i < DataList.Count; i++)
            {
                res.AppendLine($"{DataList[i].ToLongString(format)}");
            }
            return res.ToString();
        }
    }
}
