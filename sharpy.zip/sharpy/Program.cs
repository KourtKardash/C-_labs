﻿using Prac;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Prac
{
    public class Program
    {
        public static void F1(double x, ref double y1, ref double y2)
        {
            y1 = x * x * x;
            y2 = x * x * 3;
        }
        public static void F3(double x, ref double y1, ref double y2)
        {
            y1 = x * x;
            y2 = x * x * 3;
        }
        public static void F4(double x, ref double y1, ref double y2)
        {
            y1 = 2 * x * x + 3 * x * x * x;
            y2 = x * x * 3;
        }
        public static DataItem F2(double x)
        {
            return new DataItem(x, x * 2, x * x * 3);
        }
        static void Main()
        {
            Task7();
        }
        private static void Task1()
        {
            double[] x = {1, 2, 3, 4, 5};
            V2DataArray v1 = new V2DataArray("superstar", DateTime.Today, x, F1);
            Console.WriteLine(v1.ToLongString("0.##"));
            V2DataList v2 = (V2DataList)v1;
            Console.WriteLine(v2.ToLongString("0.##"));
        }
        private static void Task2() 
        {
            V2DataList v = new V2DataList("superstar", DateTime.Today);
            Console.WriteLine(v.Prop.ToLongString("0.##"));
        }
        private static void Task3_4() 
        {
            V2MainCollection v3 = new V2MainCollection(2, 3);
            Console.WriteLine(v3.ToLongString("0.##"));
            foreach (V2Data c in v3)
            {
                Console.WriteLine(c.MinField);
                //Console.WriteLine(c.IsNull);
            }
        }
        private static void Task5()
        {
            double[] x = { 1, 4, 6 };
            V2DataArray v = new V2DataArray("superstar", DateTime.Today, x, F1);
            Console.WriteLine(v.ToLongString("0.##"));
            bool q = v.Save("test.txt");
            V2DataArray v1 = new V2DataArray("", new DateTime());
            bool p = V2DataArray.Load("test.txt", ref v1);
            Console.WriteLine(v1.ToLongString("0.##"));
        }
        private static void Task6()
        {
            V2MainCollection v = new V2MainCollection(2, 3);
            Console.WriteLine(v.ToLongString("0.##"));
            Console.WriteLine("Количество нулевых значений поля:");
            Console.WriteLine(v.Count_zero);
            Console.WriteLine("Максимальный модуль поля:");
            if (v.Max_mod != null) Console.WriteLine(v.Max_mod);
            Console.WriteLine("Точки, в которых поле измерено только один раз:");
            if (v.Unique_x != null)
            {
                foreach (double c in v.Unique_x)
                {
                    Console.WriteLine(c);
                }
            }
        }
        private static void Task7()
        {
            V2DataArray v = new V2DataArray("superstar", DateTime.Today, 5, 0, 1, F1);
            //Console.WriteLine(v.ToLongString("0.##"));
            SplineData s = new SplineData(v, 0, 3, 9);
            s.method();
            s.Save("Out.txt", "F6");
        }
    }
}
