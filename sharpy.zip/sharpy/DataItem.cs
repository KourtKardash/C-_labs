﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac
{
    public struct DataItem
    {
        public double x {  get; set; }
        public double[] field { get; set; } //автореализуемые поля
        public DataItem (double x, double y1, double y2)
        {
            this.x = x;
            field = new double[] { y1, y2 };
        }
        public string ToLongString(string format)
        {
            return $"x = {x.ToString(format)}; y1 = {field[0].ToString(format)}; y2 = {field[1].ToString(format)}";
        }
        public override string ToString()
        {
            return $"x = {x}; y1 = {field[0]}; y2 = {field[1]}";
        }
    }
}