﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac
{
    public abstract class V2Data : IEnumerable<DataItem>
    {
        public abstract IEnumerator<DataItem> GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        public string key {  get; set; }
        public DateTime Date { get; set; }
        public V2Data(string key, DateTime date)
        {
            this.key = key;
            Date = date;
        }
        public abstract double MinField { get; } //не имеющий реализации
        public abstract bool IsNull { get; }
        public abstract string ToLongString(string format);
        public override string ToString() //перегруженный метод
        {
            return $"Key = {key}\nDate = {Date}";
        }
    }
}
