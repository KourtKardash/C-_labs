﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Printing;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using Prac;
namespace WpfApp1
{
    public class ViewData : INotifyPropertyChanged, IDataErrorInfo
    {
        FValues[] delsArray = new FValues[] { Program.F1, Program.F3, Program.F4 };
        public string Error { get { throw new FormatException(); } }
        public string this[string property]
        {
            get
            {
                string? msg = null;
                switch(property)
                {
                    case "NX":
                        if (NX < 3)
                        {
                            msg = "The number of grid nodes must be greater than or equal to three";
                        }
                        break;
                    case "NS":
                        if (NS < 3)
                        {
                            msg = "The number of spline nodes must be greater than or equal to three";
                        }
                        break;
                    case "XLR":
                        if (XLR[0] >= XLR[1])
                        {
                            msg = "The left end of the segment should be smaller than the right one";
                        }
                        break;
                    default:
                        break;
                }
                return msg;
            }
        }
        public Plot plotModel { get; set; }

        static private double[] xLR = new double[2] { 0, 1 }; //границы отрезка

        public double[] XLR
        {
            get { return xLR; }
            set
            {
                xLR[0] = value[0];
                xLR[1] = value[1];
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("xLR"));
            }
        }

        static private int nx = 5; //число узлов сетки

        public int NX
        {
            get { return nx; }
            set
            {
                nx = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("nx"));
            }
        }

        private bool grid = true; //тип сетки

        public bool Grid
        {
            get { return grid; }
            set
            {
                grid = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("grid"));
            }
        }

        private static int nS = 9; //число узлов сплайна

        public int NS
        {
            get { return nS; }
            set
            {
                nS = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("nS"));
            }
        }

        private static double d1L = 0; //значение производной на левом конце

        public double D1L
        {
            get { return d1L; }
            set
            {
                d1L = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("d1L"));
            }
        }

        private static double d1R = 3; //значение производной на правом конце

        public double D1R
        {
            get { return d1R; }
            set
            {
                d1R = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("d1R"));
            }
        }

        private static int index_of_function = 0; // индекс функции

        public int IndexOfFunction
        {
            get { return index_of_function; }
            set
            {
                index_of_function = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("func"));
            }
        }

        private static string string_of_item = ""; //текст пункта в splinedata

        public string StringOfItem
        {
            get { return string_of_item; }
            set
            {
                string str = (string)value;
                string_of_item = str;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("StringOfItem"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public ViewData() {}

        private static V2DataArray? DataArray;
        public SplineData? spline;


        //Коллекция для data_array
        public ObservableCollection<string> array_data = new ObservableCollection<string>();

        public void Array_()
        {
            for (int i = 0; i < nx; ++i)
            {
                array_data.Add($"x = {DataArray.X[i].ToString("F3")} y1 = {DataArray.Field[0, i].ToString("F3")}");
            }
            return;
        }

        public ObservableCollection<SplineDataItem> spline_data = new ObservableCollection<SplineDataItem>();

        public void Spline_()
        {
            for (int i = 0; i < NS; i++)
            {
                //SplineDataItem p = new SplineDataItem(Math.Round(y[i].X, 3), Math.Round(y[i].Y, 3), Math.Round(y[i].Y_p, 3));
                spline_data.Add(spline.SplineElems[i]);
            }
            return;
        }


        public void Definition ()
        {
            try
            {
                if (grid == true)
                {
                    //if (xLR[0] >= xLR[1]) throw new FormatException();
                    //if (nx <= 2) throw new FormatException();
                    DataArray = new V2DataArray("super", DateTime.Today, nx, xLR[0], xLR[1], delsArray[index_of_function]);
                }
                else
                {
                    Random rand = new Random();
                    double[] x = new double[nx];
                    x[0] = xLR[0];
                    x[nx - 1] = xLR[1];
                    for (int i = 1; i < nx - 1; ++i)
                    {
                        x[i] = Math.Round(xLR[0] + 0.01 + rand.NextDouble() * (xLR[1] - xLR[0] - 0.02), 3);
                    }
                    Array.Sort(x);
                    DataArray = new V2DataArray("super", DateTime.Today, x, delsArray[index_of_function]);
                }
                //if (nS <= 2) throw new FormatException();
                spline = new SplineData(DataArray, d1L, d1R, nS);
                spline.method();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        public void Clear()
        {
            DataArray = null;
            spline = null;
        }
        public void Save(string filename)
        {

            DataArray.Save(filename);
            return;
        }
        public void Load(string filename)
        {
            try
            {
                DataArray = new V2DataArray("", new DateTime());
                V2DataArray.Load(filename, ref DataArray);
                NX = DataArray.X.Length;
                XLR = new double[2] { DataArray.X[0], DataArray.X[NX - 1] };
                spline = new SplineData(DataArray, d1L, d1R, nS);
                spline.method();
                return;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
    }
}
