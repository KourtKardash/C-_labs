﻿using Prac;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO.Packaging;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private ViewData link = new ViewData();
        public MainWindow()
        {
            try
            {
                InitializeComponent();
                this.DataContext = link;

                //Binding bd1 = new Binding();
                //bd1.Source = link;
                //bd1.Path = new PropertyPath("XLR");
                //bd1.Converter = new BordersConverter();
                //TB1.SetBinding(TextBox.TextProperty, bd1);

                //Binding bd2 = new Binding();
                //bd2.Source = link;
                //bd2.Path = new PropertyPath("NX");
                //TB2.SetBinding(TextBox.TextProperty, bd2);

                //Binding bd3 = new Binding();
                //bd3.Source = link;
                //bd3.Path = new PropertyPath("NS");
                //TB3.SetBinding(TextBox.TextProperty, bd3);

                Binding bd4 = new Binding();
                bd4.Source = link;
                bd4.Path = new PropertyPath("D1L");
                TB4.SetBinding(TextBox.TextProperty, bd4);

                Binding bd5 = new Binding();
                bd5.Source = link;
                bd5.Path = new PropertyPath("D1R");
                TB5.SetBinding(TextBox.TextProperty, bd5);

                ArrayList.ItemsSource = link.array_data;

                SplineList.ItemsSource = link.spline_data;

                CB.ItemsSource = new string[] { "x^3", "x^2", "2x^2+3x^3" };
                Binding Binding_DAFunctionID = new Binding(); // Выбор функции
                Binding_DAFunctionID.Source = link;
                Binding_DAFunctionID.Path = new PropertyPath("IndexOfFunction");
                CB.SetBinding(ComboBox.SelectedIndexProperty, Binding_DAFunctionID);

                Binding bd6 = new Binding();
                bd6.Source = link;
                bd6.Path = new PropertyPath("StringOfItem");
                SplineList.SetBinding(ListBox.SelectedItemProperty, bd6);

                Binding bd7 = new Binding();
                bd7.Source = link;
                bd7.Path = new PropertyPath("StringOfItem");
                Out.SetBinding(TextBlock.TextProperty, bd7);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                link.Definition();
                link.Array_();
                link.Spline_();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            link.Grid = true;
        }
        private void RadioButton_Checked1(object sender, RoutedEventArgs e)
        {
            link.Grid = false;
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            link.array_data.Clear();
            link.spline_data.Clear();
            link.StringOfItem = "";
            link.Clear();
        }
        /*
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                dlg.FileName = "Document"; // Default file name
                dlg.DefaultExt = ".txt"; // Default file extension
                dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

                // Show save file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                // Process save file dialog box results
                if (result == true)
                {
                    // Save document
                    link.Save(dlg.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void File_click(object sender, RoutedEventArgs e)
        {
            try
            {
                Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                dlg.FileName = "Document"; // Default file name
                dlg.DefaultExt = ".txt"; // Default file extension
                dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

                // Show save file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                // Process save file dialog box results
                if (result == true)
                {
                    // Save document
                    link.Save(dlg.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        */
        private void Button_Click_3(object sender, RoutedEventArgs e) //импорт из файла
        {
            try
            {
                Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
                dlg.FileName = "Document"; // Default file name
                dlg.DefaultExt = ".txt"; // Default file extension
                dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

                // Show open file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                // Process open file dialog box results
                if (result == true)
                {
                    // Open document
                    link.Load(dlg.FileName);
                    link.Array_();
                    link.Spline_();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /*
        private void Button_Click_4(object sender, RoutedEventArgs e) //импорт из элементов упрвления
        {
            try
            {
                link.Definition();
                link.Array_();
                link.Spline_();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Execute_click_1(object sender, RoutedEventArgs e) //импорт из элементов упрвления
        {
            try
            {
                link.Definition();
                link.Array_();
                link.Spline_();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        */
        private void Execute_click_2(object sender, RoutedEventArgs e) //импорт из файла
        {
            try
            {
                Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
                dlg.FileName = "Document"; // Default file name
                dlg.DefaultExt = ".txt"; // Default file extension
                dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

                // Show open file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                // Process open file dialog box results
                if (result == true)
                {
                    // Open document
                    link.Load(dlg.FileName);
                    link.Array_();
                    link.Spline_();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void ExecuteHandler(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                link.Definition();
                link.Array_();
                link.Spline_();
                link.plotModel = new Plot(link.spline);
                this.DataContext = null;
                this.DataContext = link;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void CanExecuteHandler(object sender, CanExecuteRoutedEventArgs e)
        {
            if (TB1 != null && TB2 != null && TB3 != null)
            {
                if (Validation.GetHasError(TB1) == true || Validation.GetHasError(TB2) == true || Validation.GetHasError(TB3) == true)
                {
                    e.CanExecute = false;
                    return;
                }
                e.CanExecute = true;
            }
            else e.CanExecute = false;
        }
        private void SaveCommandHandler(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
                dlg.FileName = "Document"; // Default file name
                dlg.DefaultExt = ".txt"; // Default file extension
                dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

                // Show save file dialog box
                Nullable<bool> result = dlg.ShowDialog();

                // Process save file dialog box results
                if (result == true)
                {
                    // Save document
                    link.Save(dlg.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void CanSaveCommandHandler(object sender, CanExecuteRoutedEventArgs e)
        {
            if (TB1 != null && TB2 != null)
            {
                if (Validation.GetHasError(TB1) == true || Validation.GetHasError(TB2) == true || Validation.GetHasError(TB3) == true)
                {
                    e.CanExecute = false;
                    return;
                }
                e.CanExecute = true;
            }
            else e.CanExecute = false;
        }
    }
}
