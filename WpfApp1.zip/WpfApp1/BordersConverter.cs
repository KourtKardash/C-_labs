﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace WpfApp1
{
    //[ValueConversion(typeof(string), typeof(double[]))]
    class BordersConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            double[] arr = (double[])value;
            string str1 = arr[0].ToString();
            string str2 = arr[1].ToString();
            return str1 + ' ' + str2;
        }
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            try
            {
                string str = (string)value;
                if(!str.Contains(' ')) throw new FormatException();
                if(str.LastIndexOf(' ') != str.IndexOf(' ')) 
                    throw new FormatException();
                if(str.LastIndexOf(' ') == str.Length-1) throw new FormatException();
                int ind = str.IndexOf(' ');

                string s1 = str.Substring(0, ind);
                if(s1.LastIndexOf(',') != s1.IndexOf(','))
                    throw new FormatException();
                for (int i = 0; i < s1.Length; ++i)
                {
                    if (s1[i] < 44 || s1[i] > 57 || s1[i] == 47 || s1[i] == 46) throw new FormatException();
                }

                string s2 = str.Substring(ind + 1, str.Length - ind - 1);
                if (s2.LastIndexOf(',') != s2.IndexOf(','))
                    throw new FormatException();
                for (int i = 0; i < s2.Length; ++i)
                {
                    if (s2[i] < 44 || s2[i] > 57 || s2[i] == 47 || s2[i] == 46) throw new FormatException();
                }
                double[] arr = new double[2];
                arr[0] = Double.Parse(s1);
                arr[1] = Double.Parse(s2);
                return arr;
            }
            catch (FormatException ex)
            {
                MessageBox.Show(ex.Message);
                double[] x = new double[2] { 0, 1 };
                return x;
            }
        }
    }
}
