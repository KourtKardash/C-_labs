﻿using Prac;
using OxyPlot;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OxyPlot.Series;
using OxyPlot.Legends;

namespace WpfApp1
{
    public class Plot
    {
        SplineData data { get; set; }
        public PlotModel plotModel { get; private set; }
        public Plot(SplineData data)
        {
            this.data = data;
            plotModel = new PlotModel { Title = "Aппроксимация" };
            OxyPlot.Axes.LinearAxis XAxis = new OxyPlot.Axes.LinearAxis { Position = OxyPlot.Axes.AxisPosition.Bottom };
            OxyPlot.Axes.LinearAxis YAxis = new OxyPlot.Axes.LinearAxis { Position = OxyPlot.Axes.AxisPosition.Left };
            XAxis.Title = "X";
            YAxis.Title = "Y";
            plotModel.Axes.Add(YAxis);
            plotModel.Axes.Add(XAxis);

            var graph1 = new OxyPlot.Series.LineSeries()
            {
                Title = $"Дискретные значения функции",
                Color = OxyColors.Transparent,
                MarkerSize = 6,
                MarkerType = OxyPlot.MarkerType.Star,
                MarkerFill = OxyColors.Brown,
                MarkerStroke = OxyColors.Brown
            };
            var points = data.DataArray.X;
            var values = data.DataArray[0];
            for (int i = 0; i < points.Length; i++)
            {
                graph1.Points.Add(new DataPoint(points[i], values[i]));
            }
            
            
            Legend legend = new Legend { LegendPosition = LegendPosition.LeftTop, LegendPlacement = LegendPlacement.Inside };
            plotModel.Legends.Add(legend);

            var graph2 = new OxyPlot.Series.LineSeries()
            {
                Title = $"Аппроксимирующий сплайн",
                Color = OxyColors.Pink,
                MarkerSize = 3,
                MarkerType = OxyPlot.MarkerType.Circle,
                MarkerFill = OxyColors.Pink,
                MarkerStroke = OxyColors.Pink
            };

            var SplineElems = data.SplineElems;
            foreach (var s in SplineElems)
            {
                graph2.Points.Add(new DataPoint(s.X, s.Y));
            }

            plotModel.Series.Add(graph2);

            legend = new Legend { LegendPosition = LegendPosition.LeftTop, LegendPlacement = LegendPlacement.Inside };
            plotModel.Legends.Add(legend);

            plotModel.Series.Add(graph1);
        }
    }
}
