﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp1
{
    public static class Command
    {
        public static RoutedCommand ExecuteCommand = new RoutedCommand("ExecuteCommand", typeof(WpfApp1.Command));
    }
}
